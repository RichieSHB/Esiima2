export class perfil{
    constructor(public name:string, public email:string){}
    
}