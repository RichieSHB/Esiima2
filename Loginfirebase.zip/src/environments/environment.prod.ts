export const environment = {
  firebase: {
    projectId: 'esiima-2',
    appId: '1:474509516729:web:be689e90257567b309e068',
    databaseURL: 'https://esiima-2-default-rtdb.firebaseio.com',
    storageBucket: 'esiima-2.appspot.com',
    apiKey: 'AIzaSyCfeweMm0G6eJpxOHywdN8zaVD5shFHPd0',
    authDomain: 'esiima-2.firebaseapp.com',
    messagingSenderId: '474509516729',
    measurementId: 'G-EDGNRM9MLB',
  },
  production: true
};
